class Item:
    
    def __init__(self, name, description, item_type):
        self.name = name
        self.description = description
        self.item_type = item_type

   
